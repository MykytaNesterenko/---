#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    cout.setf(ios::fixed);
    cout << setprecision(4);

    cout << "=== Завдання Begin33 ===" << endl;
    cout << "Введiть сторону куба a (дiйсне число):" << endl;
    double a;
    cin >> a;

    double S1 = a * a;             // площа гранi
    double surface = 6.0 * S1;     // площа поверхнi куба
    double ratio = (S1 == 0.0) ? 0.0 : (surface / S1);

    cout << "Площа гранi S1 = " << S1 << endl;
    cout << "Площа поверхнi куба = " << surface << endl;
    cout << "Вiдношення площi поверхнi до площi гранi = " << ratio << endl;

    return 0;
}