#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    cout.setf(ios::fixed);
    cout << setprecision(4);

    cout << "=== Завдання Begin19 ===" << endl;
    cout << "Введiть число A (дiйсне):" << endl;
    double A_val;
    cin >> A_val;

    double b, c;
    b = A_val * A_val;       // A^2
    c = b * A_val;           // A^3
    b = c * b;               // A^5
    c = b * b;               // A^10
    double A15 = c * b;      // A^15

    cout << "A^15 = " << A15 << endl;
    return 0;
}