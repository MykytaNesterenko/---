#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    cout.setf(ios::fixed);
    cout << setprecision(4);

    cout << "=== Завдання Begin24 ===" << endl;
    cout << "Введiть X (кг цукерок) та A (вартiсть у грн) через пробiл:" << endl;

    double X, A;
    cin >> X >> A;

    if (X == 0.0) {
        cout << "Помилка: X не повинно бути нулем." << endl;
    } else {
        double price_per_kg = A / X;
        cout << "1 кг коштує (грн): " << price_per_kg << endl;

        cout << "Введiть Y (скiльки кг потрiбно обчислити):" << endl;
        double Y;
        cin >> Y;

        double cost_Y = price_per_kg * Y;
        cout << Y << " кг коштують (грн): " << cost_Y << endl;
    }
    return 0;
}